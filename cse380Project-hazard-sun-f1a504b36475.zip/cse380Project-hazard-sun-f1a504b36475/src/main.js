import config from './config.js';
import gameScene from './scenes/gameScene.js';
import preloaderScene from './scenes/preloadScene.js';
import titleScene from './scenes/titleScene.js';
import controlsScene from './scenes/controlsScene.js';
import helpScene from './scenes/helpScene.js';
import levelsScene from './scenes/levelsScene.js';
import pausedScene from './scenes/pausedScene.js';
import pausedControls from './scenes/pausedControls.js';


// Load our scenes
var PreloaderScene = new preloaderScene();
var TitleScene = new titleScene();
var GameScene = new gameScene();
var ControlsScene = new controlsScene();
var HelpScene = new helpScene();
var LevelsScene = new levelsScene();
var PausedScene = new pausedScene();
var PausedControls = new pausedControls();


var game = new Phaser.Game(config);

// load scenes
game.scene.add('preloadScene', PreloaderScene);
game.scene.add('titleScene', TitleScene);
game.scene.add('controlsScene', ControlsScene);
game.scene.add("gameScene", GameScene);
game.scene.add("helpScene", HelpScene);
game.scene.add("levelsScene", LevelsScene);
game.scene.add("pausedScene", PausedScene);
game.scene.add("pausedControls", PausedControls);


// start title
game.scene.start('Preload');