export default class preloadScene extends Phaser.Scene {
  constructor () {
    super('Preload');
  }
 
  preload () {
    this.load.setBaseURL('images/');
    this.load.image('logo', 'logo.png');
    this.load.image('start_button', 'start_button.png')
    this.load.image('back_button', 'back_button.png');
    this.load.image('background', 'main_menu_background.png');
    this.load.image('background_blurred', 'main_menu_background_blurred.png')
    this.load.image('title', 'Title.png');
    this.load.image('title2', 'Title2.png');
    this.load.image('start', 'Start.png');
    this.load.image('level select', 'Level Select.png');
    this.load.image('controls', 'Controls.png');
    this.load.image('help', 'Help.png');
    this.load.image('level title', 'Level Select Title.png');
    this.load.image('controls title', 'Controls Title.png');
    this.load.image('help title', 'Help Title.png');
    this.load.image('1', 'level1.png');
    this.load.image('2', 'level2.png');
    this.load.image('3', 'level3.png');
    this.load.image('4', 'level4.png');
    this.load.image('5', 'level5.png');
    this.load.image('6', 'level6.png');
    this.load.image('7', 'level7.png');
    this.load.image('8', 'level8.png');
    this.load.image('select', 'levelselect.png');
    this.load.image('wasd', 'wasd.png');
    this.load.image('space', 'space.png');
    this.load.image('esc', 'esc.png');
    this.load.image('wasd text', 'wasd text.png');
    this.load.image('space text', 'space text.png');
    this.load.image('esc text', 'esc text.png');
    this.load.image('backstory', 'Backstory.png');
    this.load.image('characters', 'Characters.png');
    this.load.image('devs', 'Devs.png');
    this.load.image('backstory text', 'Backstory text.png');
    this.load.image('characters text', 'Characters text.png');
    this.load.image('devs text', 'Devs text.png');
    this.load.image('gameover', 'gameover.png');
    this.load.image('mainmenu', 'mainmenu.png');
    this.load.image('restart', 'restart.png');
    this.load.image('paused', 'Paused.png');
    this.load.image('pause_menu', 'Pause_Menu.png');
    this.load.image('pause_restart', 'Pause_restart.png');
    this.load.image('pause_controls', 'Pause_controls.png');
    this.load.image('back', 'Back.png');
    this.load.image('exit', 'Exit.png');
    this.load.image('win', 'win.png');
    this.load.image('next_level', 'Next_Level.png');
    this.load.image('next_menu', 'Next_Menu.png');
    this.load.image('waterBar', 'waterBar.png');
    this.load.image('waterMeter', 'waterMeter.png');
    this.load.image('bonus', 'bonus.png');

    
    this.load.spritesheet('sky', 
      'sky.png',
      { frameWidth: 1200, frameHeight: 800 }
    );
    this.load.spritesheet('mizu', 
      'Mizu.png',
      { frameWidth: 64, frameHeight: 64 }
    );
    this.load.spritesheet('sapling',
      'Sapling.png',
      { frameWidth: 256, frameHeight: 320}
    );
    this.load.spritesheet('tree',
      'SaplingToTree.png',
      { frameWidth: 256, frameHeight: 320}
    );
    this.load.spritesheet('enemy',
      'flame_sprite.png',
      { frameWidth: 128, frameHeight: 128}
    );
    this.load.spritesheet('leaf',
      'leaf.png',
      { frameWidth: 64, frameHeight: 64}
      );
    this.load.spritesheet('waterdrop',
      'water_pickup.png',
      { frameWidth: 32, frameHeight: 32}
    );

    this.load.audio('main', '../music/background.wav');
    this.load.audio('death', '../music/death.wav');
    this.load.audio('grow', '../music/grow.wav');
    this.load.audio('hurt', '../music/hurt.wav');
    this.load.audio('jump', '../music/Jump.wav');
    this.load.audio('water', '../music/water.wav');
    this.load.audio('click', '../music/click.mp3');

    this.load.tilemapTiledJSON("level1", "level1.json");
    this.load.tilemapTiledJSON("level2", "level2.json");
    this.load.tilemapTiledJSON("level3", "level3.json");
    this.load.tilemapTiledJSON("level4", "level4.json");
    this.load.tilemapTiledJSON("level5", "level5.json");
    this.load.tilemapTiledJSON("level6", "level6.json");
    this.load.tilemapTiledJSON("level7", "level7.json");
    this.load.tilemapTiledJSON("level8", "level8.json");
    this.load.tilemapTiledJSON("level9", "level9.json");
    this.load.image("tiles", "tiles.png");
    this.load.image("shade", "shade.png")
    this.load.image("water", "water.png")
    this.load.image("shadedPlatform", "shade_floating.png")
  }

  create () {
    var music = this.sound.add('main');
    music.volume-= 0.5;
    music.play({loop: true});
    this.add.image(600,400, 'background');
    this.add.image(850,90, 'title');

    var startButton = this.add.image(900,350, 'start_button');
    startButton.setInteractive({ useHandCursor: true });
    startButton.on('pointerdown', () => this.clickButton());
  }

  clickButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Title');
  }
};