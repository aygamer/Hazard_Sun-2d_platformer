export default class pausedScene extends Phaser.Scene {
    constructor () {
      super('Paused');
    }

    init(){
        this.imageGroup;
    }

    preload(){}

    create(){
        this.imageGroup = this.add.group();
        var image = this.add.image(600,400, 'pause_menu');
        this.imageGroup.add(image);
        image = this.add.image(600,200, 'paused');
        this.imageGroup.add(image);
        var button = this.add.image(600,320, 'back');
        button.setInteractive({ useHandCursor: true });
        button.on('pointerdown', () => this.resume());
        this.imageGroup.add(button);
        button = this.add.image(600,400, 'pause_restart');
        button.setInteractive({ useHandCursor: true });
        button.on('pointerdown', () => this.restartButton());
        this.imageGroup.add(button);
        button = this.add.image(600,480, 'pause_controls');
        button.setInteractive({ useHandCursor: true });
        button.on('pointerdown', () => this.controls());
        this.imageGroup.add(button);
        button = this.add.image(600,560, 'exit');
        button.setInteractive({ useHandCursor: true });
        button.on('pointerdown', () => this.menuButton());
        this.imageGroup.add(button);
    }

    resume(){
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.imageGroup.destroy(true);
        this.scene.resume('Game');
        this.scene.stop();
    }

    menuButton() {
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.scene.stop('Game');
        this.scene.start('Title');
    }

    restartButton() {
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.scene.start('Game');
    }

    controls(){
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.scene.pause();
        this.scene.launch("PausedControls");
    }
}