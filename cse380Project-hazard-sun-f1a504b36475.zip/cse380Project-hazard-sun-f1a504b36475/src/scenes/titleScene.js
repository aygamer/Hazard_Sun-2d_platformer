export default class titleScene extends Phaser.Scene {
  constructor () {
    super('Title');
  }
 
  preload () {
  }
 
  create () {
    this.add.image(600,400, 'background_blurred');
    this.add.image(410,200, 'logo');
    this.add.image(730, 200, 'title2').setScale(1.3);

    var text = this.add.image(600,400, 'start');
    text.setInteractive({ useHandCursor: true });
    text.on('pointerdown', () => this.startButton());

    var text = this.add.image(600,480, 'level select');
    text.setInteractive({ useHandCursor: true });
    text.on('pointerdown', () => this.levelButton());

    var text = this.add.image(600,560, 'controls');
    text.setInteractive({ useHandCursor: true });
    text.on('pointerdown', () => this.controlButton());

    var text = this.add.image(600,640, 'help');
    text.setInteractive({ useHandCursor: true });
    text.on('pointerdown', () => this.helpButton());
  }

  startButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Game', { level: 1});
  }
  levelButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Levels');
  }
  controlButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Controls');
  }
  helpButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Help');
  }
};