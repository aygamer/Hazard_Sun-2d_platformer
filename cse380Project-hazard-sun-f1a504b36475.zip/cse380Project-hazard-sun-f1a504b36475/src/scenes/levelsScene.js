export default class levelsScene extends Phaser.Scene {
    constructor () {
      super('Levels');
    }
   
    preload () {
    }

   
    create () {
        this.add.image(600,400, 'background_blurred');
        var logo = this.add.image(370,120, 'logo');
        logo.setScale(0.5)
        this.add.image(680, 120, "level title");
        var back = this.add.image(90,40, 'back_button').setInteractive({ useHandCursor: true });
        back.on('pointerdown', () => this.backButton());

        this.add.image(600,500,'select');
        var text = this.add.image(200,370, '1').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(1));
        text = this.add.image(440,370, '2').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(2));
        text = this.add.image(710,370, '3').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(3));
        text = this.add.image(980,370, '4').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(4));
        text = this.add.image(200,610, '5').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(5));
        text = this.add.image(440,610, '6').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(6));
        text = this.add.image(710,610, '7').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(7));
        text = this.add.image(980,610, '8').setInteractive({ useHandCursor: true });
        text.on('pointerdown', () => this.levelButton(8));
    }

    levelButton(levelNumber){
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.scene.start('Game', {level: levelNumber});
    }
    backButton() {
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.scene.start('Title');
    }
  };