export default class gameScene extends Phaser.Scene {

  constructor () {
    super('Game');
  }

  init (data) {
    this.level = data.level;
    this.player;
    this.cursors;
    //Keys to watch for
    this.a;
    this.w;
    this.s;
    this.d;
    this.space;
    this.esc;
    this.i;
    this.one;
    this.two;
    this.three;
    this.four;
    this.five;
    this.six;
    this.seven;
    this.eight;
    this.nine;

    this.warningTimer = -1;
    this.warning;
    //Player resources
    this.treesWatered = 0;
    this.maxSaplings;
    this.waterMeter = 100;
    this.waterBar;
    this.waterMask;
    this.invincible = false;
    this.waterUpgraded = false;

    this.waterText;
    this.treeText;
    //map stuff
    this.map;
    this.tiles;
    this.water;
    this.sky;

    this.waterTimer = 0;
    this.beatLevel = false;
    this.shade;
    this.shadeTimer = 60;
    this.jumpable = false;
    this.shadedPlatform;

    this.enemies;
    this.enemyIdling = true;
    this.enemyTimer = 60;

    this.powerups;
  }
 
  preload () {
  }
 
  create () {  
    //Initial background first
    this.sky = this.add.sprite(600, 400, 'sky').setScrollFactor(0);

    //Load the map based on what level the user is at
    if (this.level == null){
      this.map = this.make.tilemap({key: 'level1'});
    }else{
      this.map = this.make.tilemap({key: 'level' + this.level});
    }
    this.tiles = this.map.addTilesetImage('tiles', 'tiles');
    
    //Ground layer
    var groundLayer = this.map.createStaticLayer('Ground', this.tiles, 0, 0);
    groundLayer.setCollisionByProperty({ collides: true });

    //Water layer
    this.water = this.physics.add.group({
      allowGravity: false,
      immovable: true
    });
    var waterTiles = this.map.getObjectLayer('Water')['objects'];
    waterTiles.forEach(waterTile => {
      var water = this.water.create(waterTile.x, waterTile.y - 32, 'water').setOrigin(0, 0);
      water.body.setSize(water.width, water.height);
    });

    //Shade layer
    this.shade = this.physics.add.group({
      allowGravity: false,
      immovable: true
    });
    var shadeTiles = this.map.getObjectLayer('Shade')['objects'];
    shadeTiles.forEach(shadeTile => {
      var shade = this.shade.create(shadeTile.x, shadeTile.y - 32, 'shade').setOrigin(0, 0);
      shade.body.setSize(shade.width, shade.height);
    });

    //Shaded platform layer
    this.shadedPlatform = this.physics.add.group({
      allowGravity: false,
      immovable: true
    });
    var shadedTiles = this.map.getObjectLayer('Shaded Platform')['objects'];
    shadedTiles.forEach(shadeTile => {
      var shade = this.shadedPlatform.create(shadeTile.x, shadeTile.y - 32, 'shadedPlatform').setOrigin(0, 0);
      shade.body.setSize(shade.width, shade.height);
    });


    //Trees groups for the hidden trees saps grow into, statictree for static trees for shade, and saps for saps to water. Enemies and powerups groups
    this.trees = this.physics.add.group();
    this.statictree = this.physics.add.group();
    this.saps = this.physics.add.group();
    this.enemies = this.physics.add.group();
    this.powerups = this.physics.add.group();


    //Spawn trees, enemies, and Mizu in based on what level player is in
    this.spawnStuff();

    this.trees.getChildren().forEach( treevis => {
      treevis.setVisible(false);
    });
    this.maxSaplings = this.saps.countActive();


    //Game world bounds
    this.physics.world.setBounds(0, 0, this.map.widthInPixels, this.map.heightInPixels);

    //Resource meters
    this.treeText = this.add.text(885, 70, 'Saplings Watered: ' + this.treesWatered + '/' + this.maxSaplings, {color: '#000000'}).setScrollFactor(0);
    this.add.image(1030, 35, 'waterMeter').setScrollFactor(0);
    this.waterBar = this.add.sprite(1030, 35, 'waterBar').setScrollFactor(0);
    this.waterMask = this.add.sprite(1030, 35, 'waterBar').setScrollFactor(0);
    this.waterMask.visible = false;
    this.waterBar.mask = new Phaser.Display.Masks.BitmapMask(this, this.waterMask);
    this.waterText = this.add.text(885,27,'Water Meter: ' + this.waterMeter + '/100', {color: '#000000'}).setScrollFactor(0);


    //Physics collisions
    this.player.setCollideWorldBounds(true);
    this.physics.add.collider(this.player, groundLayer);
    this.physics.add.collider(this.enemies, groundLayer);
    this.physics.add.collider(this.powerups, groundLayer);
    this.physics.add.collider(this.trees, groundLayer);
    this.physics.add.collider(this.saps, groundLayer);
    this.physics.add.collider(this.statictree, groundLayer);

    this.physics.add.collider(this.player, this.shade);
    this.physics.add.collider(this.enemies, this.shade);
    this.physics.add.collider(this.powerups, this.shade);
    this.physics.add.collider(this.trees, this.shade);
    this.physics.add.collider(this.saps, this.shade);
    this.physics.add.collider(this.statictree, this.shade);

    this.physics.add.collider(this.player, this.shadedPlatform);
    this.physics.add.collider(this.enemies, this.shadedPlatform);
    this.physics.add.collider(this.powerups, this.shadedPlatform);
    this.physics.add.collider(this.trees, this.shadedPlatform);
    this.physics.add.collider(this.saps, this.shadedPlatform);
    this.physics.add.collider(this.statictree, this.shadedPlatform);

    //Camera
    this.cameras.main.setBounds(0, 0, this.map.widthInPixels, this.map.heightInPixels);
    this.cameras.main.startFollow(this.player);

    //Animations
    this.createAnimations();
    //Enemies, trees/saps, and background idle by default
    this.trees.getChildren().forEach( treeanims => {
      treeanims.anims.play('tree idle', true);
    });
    this.statictree.getChildren().forEach( treeanims => {
      treeanims.anims.play('tree idle', true);
    });
    this.saps.getChildren().forEach( sapanims => {
      sapanims.anims.play('sapling idle', true);
    });
    this.enemies.getChildren().forEach( enemy => {
      enemy.anims.play('enemyRight');
    });
    this.sky.anims.play('background', true);
    
    //Key tracking/registers
    this.inputSetup();
  }

  update (){
    /////////////////////////////////////////////////////REMOVE WHEN DONE
    console.log("(X: " + this.player.x + ", Y: " + this.player.y + ")");
    //Reset horizontal velocity and ability to jump
    this.player.setVelocityX(0);
    this.jumpable = false;

    //Death check
    if (this.waterMeter <= 0){
      if (this.player.anims.getCurrentKey() != 'dying'){
        this.dead();
      }
    }//Win the game check
    else if (this.treesWatered == this.maxSaplings){
      if (!this.beatLevel){
        this.finishedLevel();
      }else{
        this.beatLevel = true;
      }
    }
    //Not dead or beat level, in water check
    else{
      var min = 500;
      this.water.getChildren().forEach(waterTile => {
        var dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, waterTile.x, waterTile.y);
        if (dist < min){
          min = dist;
        }
      });
      //Collision detections for how far Mizu is to water tile
      if (min <= 20){
        this.inWater();
      }else{
        //If Mizu's not in water, shade check
        var min = 500;
        this.shade.getChildren().forEach(shadeTile => {
          var dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, shadeTile.x, shadeTile.y);
          if (dist < min){
            min = dist;
          }
        });
        //Arbitrary collision detections for how far Mizu is to shaded tile
        if (min >= 70){
          //Same checks for shaded platforms
          this.shadedPlatform.getChildren().forEach(shadeTile => {
            var dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, shadeTile.x, shadeTile.y);
            if (dist < min){
              min = dist;
            }
          });

          if (min >= 70){
            //Dist to shaded tiles >= 70, in the sun and take damage
            this.inSun();
          }else{
            //In shade, don't take damage and can jump
            this.jumpable = true;
          }
        }else{
          //In shade, don't take damage and can jump
          this.jumpable = true;
        }
      }

      //Timer for warnings
      if (this.warningTimer > -1){
        this.warningTimer--;
        if (this.warningTimer == -1){
          this.warning.destroy();
        }
      }

      //invincibility cheat
      if (Phaser.Input.Keyboard.JustDown(this.i)){
        if (!this.invincible){
          this.invincible = true;
          if (this.warning != null){this.warning.destroy()}
          this.warning = this.add.text(500,400,"You are now invincible.", {color: '#000000'}).setScrollFactor(0);
          this.warningTimer = 120;
        }
        else if (this.invincible){
          this.invincible = false;
          if (this.warning != null){this.warning.destroy()}
          this.warning = this.add.text(500,400,"You are no longer invincible.", {color: '#000000'}).setScrollFactor(0);
          this.warningTimer = 120;
        }
      }

      //PLAYER MOVEMENT
      this.movement();

      //Watering
      this.watering();

      //Enemy movement/AI/Attacking
      this.enemyAI();

      //Powerup logic
      this.powerUp();
    }
  }


////////////////////////////////////////////////////////// Self explanatory button functions that occur in pause menu or when levels beaten

  pause(){
    if (this.waterMeter > 0){
      var sound = this.sound.add('click');
      sound.volume-= 0.4;
      sound.play();
      this.scene.pause();
      this.scene.launch('Paused');
    }
  }

  menuButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.stop('Game');
    this.scene.start('Title');
  }

  restartButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.stop('Game');
    this.scene.start('Game', {level: this.level});
  }

  levelButton(levelNumber){
    this.scene.stop('Game');
    this.scene.start('Game', {level: levelNumber});
}

  
////////////////////////////////////////////////////////// Initial setup/spawn functions

//Depending on what level, spawn trees in different coordinates
spawnStuff(){
  if (this.level == 1){
    this.statictree.add(this.physics.add.sprite(1060, 160, 'tree'));
    this.statictree.add(this.physics.add.sprite(520, 355, 'tree'));

    this.trees.add(this.physics.add.sprite(134, 225, 'tree'));
    this.saps.add(this.physics.add.sprite(134, 225, 'sapling'));
    this.trees.add(this.physics.add.sprite(1000, 545, 'tree'));
    this.saps.add(this.physics.add.sprite(1000, 545, 'sapling'));

    this.enemies.add(this.physics.add.sprite(540, 800, 'enemy'));

    this.player = this.physics.add.sprite(100, 860, 'mizu');
    this.waterTimer = 60;
  }else if (this.level == 2){
    this.statictree.add(this.physics.add.sprite(120, 355, 'tree'));
    this.statictree.add(this.physics.add.sprite(1200, 300, 'tree'));
    this.statictree.add(this.physics.add.sprite(1800, 20, 'tree'));

    this.trees.add(this.physics.add.sprite(1500, 300, 'tree'));
    this.saps.add(this.physics.add.sprite(1500, 300, 'sapling'));
    this.trees.add(this.physics.add.sprite(1800, 400, 'tree'));
    this.saps.add(this.physics.add.sprite(1800, 400, 'sapling'));
    this.trees.add(this.physics.add.sprite(880, 300, 'tree'));
    this.saps.add(this.physics.add.sprite(880, 300, 'sapling'));
    this.trees.add(this.physics.add.sprite(700, 685, 'tree'));
    this.saps.add(this.physics.add.sprite(700, 685, 'sapling'));

    this.enemies.add(this.physics.add.sprite(555, 610, 'enemy'));
    this.enemies.add(this.physics.add.sprite(1200, 385, 'enemy'));

    this.player = this.physics.add.sprite(100, 480, 'mizu');
  }else if (this.level == 3){
    this.statictree.add(this.physics.add.sprite(310, 0, 'tree'));
    this.statictree.add(this.physics.add.sprite(1480, -200, 'tree'));
    this.statictree.add(this.physics.add.sprite(1530, 675, 'tree'));

    this.trees.add(this.physics.add.sprite(1100, 800, 'tree'));
    this.saps.add(this.physics.add.sprite(1100, 800, 'sapling'));
    this.trees.add(this.physics.add.sprite(130, 800, 'tree'));
    this.saps.add(this.physics.add.sprite(130, 800, 'sapling'));

    this.enemies.add(this.physics.add.sprite(720, 800, 'enemy'));
    this.enemies.add(this.physics.add.sprite(1120, 100, 'enemy'));
    this.enemies.add(this.physics.add.sprite(1300, 610, 'enemy'));

    sprite = this.physics.add.sprite(1240,670, 'waterdrop');
    sprite.setName('water');
    this.powerups.add(sprite)

    this.player = this.physics.add.sprite(1530, 800, 'mizu');
  }else if (this.level == 4){
    this.statictree.add(this.physics.add.sprite(200, 900, 'tree'));
    this.statictree.add(this.physics.add.sprite(1330, 150, 'tree'));

    this.trees.add(this.physics.add.sprite(200, 420, 'tree'));
    this.saps.add(this.physics.add.sprite(200, 420, 'sapling'));
    this.trees.add(this.physics.add.sprite(1200, 895, 'tree'));
    this.saps.add(this.physics.add.sprite(1200, 895, 'sapling'));
    this.trees.add(this.physics.add.sprite(850, 750, 'tree'));
    this.saps.add(this.physics.add.sprite(850, 750, 'sapling'));

    this.enemies.add(this.physics.add.sprite(1450, 680, 'enemy'));
    this.enemies.add(this.physics.add.sprite(670, 315, 'enemy'));

    this.player = this.physics.add.sprite(200, 970, 'mizu');
  }else if (this.level == 5){
    this.statictree.add(this.physics.add.sprite(150, 1185, 'tree'));

    this.trees.add(this.physics.add.sprite(550, 840, 'tree'));
    this.saps.add(this.physics.add.sprite(550, 840, 'sapling'));
    this.trees.add(this.physics.add.sprite(1100, 1025, 'tree'));
    this.saps.add(this.physics.add.sprite(1100, 1025, 'sapling'));
    this.trees.add(this.physics.add.sprite(1100, 150, 'tree'));
    this.saps.add(this.physics.add.sprite(1100, 150, 'sapling'));
    this.trees.add(this.physics.add.sprite(1030, 615, 'tree'));
    this.saps.add(this.physics.add.sprite(1030, 615, 'sapling'));

    this.enemies.add(this.physics.add.sprite(750, 150, 'enemy'));
    this.enemies.add(this.physics.add.sprite(200, 765, 'enemy'));

    var sprite = this.physics.add.sprite(350, 1150, 'leaf');
    sprite.setName('leaf');
    this.powerups.add(sprite);

    this.player = this.physics.add.sprite(150, 1250, 'mizu');
  }else if (this.level == 6){
    this.trees.add(this.physics.add.sprite(1051, 400, 'tree'));
    this.saps.add(this.physics.add.sprite(1051, 400, 'sapling'));
    this.trees.add(this.physics.add.sprite(303, 670, 'tree'));
    this.saps.add(this.physics.add.sprite(303, 670, 'sapling'));
    this.trees.add(this.physics.add.sprite(310, 1640, 'tree'));
    this.saps.add(this.physics.add.sprite(310, 1640, 'sapling'));
    this.statictree.add(this.physics.add.sprite(306, 2000, 'tree'));
    // this.saps.add(this.physics.add.sprite(306, 2030, 'sapling'));
    this.statictree.add(this.physics.add.sprite(1033, 2000, 'tree'));
    // this.saps.add(this.physics.add.sprite(1033, 2030, 'sapling'));
    this.trees.add(this.physics.add.sprite(258, 2580, 'tree'));
    this.saps.add(this.physics.add.sprite(258, 2580 , 'sapling'));
    this.trees.add(this.physics.add.sprite(920, 3370, 'tree'));
    this.saps.add(this.physics.add.sprite(920, 3370, 'sapling'));

    this.enemies.add(this.physics.add.sprite(788, 1900, 'enemy'));
    this.enemies.add(this.physics.add.sprite(888, 1144, 'enemy'));
    this.enemies.add(this.physics.add.sprite(841, 2480, 'enemy'));

    var sprite = this.physics.add.sprite(976, 1710, 'leaf');
    sprite.setName('leaf');
    this.powerups.add(sprite);

    this.statictree.add(this.physics.add.sprite(280, 3550, 'tree'));
    this.player = this.physics.add.sprite(280, 3670, 'mizu');
  }else if (this.level == 7){
    this.saps.add(this.physics.add.sprite(165, 900, 'sapling'));
    this.trees.add(this.physics.add.sprite(165, 900, 'tree'));
    this.saps.add(this.physics.add.sprite(1855, 1900, 'sapling'));
    this.trees.add(this.physics.add.sprite(1855, 1900, 'tree'));
    this.saps.add(this.physics.add.sprite(2530, 1900, 'sapling'));
    this.trees.add(this.physics.add.sprite(2530, 1900, 'tree'));
    this.saps.add(this.physics.add.sprite(4383, 1000, 'sapling'));
    this.trees.add(this.physics.add.sprite(4383, 1000, 'tree'));
    this.saps.add(this.physics.add.sprite(1858, 600, 'sapling'));
    this.trees.add(this.physics.add.sprite(1858, 600, 'tree'));
    this.saps.add(this.physics.add.sprite(2558, 600, 'sapling'));
    this.trees.add(this.physics.add.sprite(2558, 600, 'tree'));
    this.saps.add(this.physics.add.sprite(135, 50, 'sapling'));
    this.trees.add(this.physics.add.sprite(135, 50, 'tree'));

    this.statictree.add(this.physics.add.sprite(420, 100, 'tree'));
    this.statictree.add(this.physics.add.sprite(4005, 1950, 'tree'));
    this.statictree.add(this.physics.add.sprite(2212, 1900, 'tree'));
    this.statictree.add(this.physics.add.sprite(1100, 800, 'tree'));

    this.enemies.add(this.physics.add.sprite(930, 50, 'enemy'));
    this.enemies.add(this.physics.add.sprite(2345, 2000, 'enemy'));  
    this.enemies.add(this.physics.add.sprite(4030, 1300, 'enemy'));

    var sprite = this.physics.add.sprite(4438, 2000, 'leaf');
    sprite.setName('leaf');
    this.powerups.add(sprite);

    var sprite = this.physics.add.sprite(1243, 300, 'leaf');
    sprite.setName('leaf');
    this.powerups.add(sprite);

    var sprite = this.physics.add.sprite(3960, 1300, 'waterdrop');
    sprite.setName('water');
    this.powerups.add(sprite);

    this.player = this.physics.add.sprite(130, 2000, 'mizu');
    // this.player = this.physics.add.sprite(3960, 1300, 'mizu');
  }
  else if (this.level == 8){
    this.statictree.add(this.physics.add.sprite(80, 1955, 'tree'));

    this.trees.add(this.physics.add.sprite(4420, 2050, 'tree'));
    this.saps.add(this.physics.add.sprite(4420, 2050, 'sapling'));

    this.enemies.add(this.physics.add.sprite(195, 1470, 'enemy'));
    this.enemies.add(this.physics.add.sprite(1050, 600, 'enemy'));
    this.enemies.add(this.physics.add.sprite(3050, 1500, 'enemy'));
    for (var i = 0; i < 30; i++){
      this.enemies.add(this.physics.add.sprite(1510 + 25*i, 2050, 'enemy'));
    }
    for (var i = 0; i < 14; i++){
      this.enemies.add(this.physics.add.sprite(3920 + 30*i, 1100, 'enemy'));
    }
    this.enemies.add(this.physics.add.sprite(3450, 600, 'enemy'));

    var sprite = this.physics.add.sprite(480, 970, 'leaf');
    sprite.setName('leaf');
    this.powerups.add(sprite);
    for (var i = 0; i < 8; i++){
      var sprite = this.physics.add.sprite(2225 + i*23, 900, 'waterdrop');
      sprite.setName('water');
      this.powerups.add(sprite);
    }
    var sprite = this.physics.add.sprite(3950, 490, 'waterdrop');
    sprite.setName('water');
    this.powerups.add(sprite);

    this.player = this.physics.add.sprite(100, 2050, 'mizu');
  }
  else if (this.level == 9){
    this.waterTimer = 240;
    this.warning = this.add.text(280,400,"Congrats, you beat the game! Now enjoy killing all these sprites :)", {color: '#000000'}).setScrollFactor(0);
    this.trees.add(this.physics.add.sprite(1500, 520, 'tree'));
    this.saps.add(this.physics.add.sprite(1500, 520, 'sapling'));

    for (var i = 0; i < 30; i++){
      this.enemies.add(this.physics.add.sprite(430 + 30*i, 610, 'enemy'));
    }
    for (var i = 0; i < 45; i++){
      sprite = this.physics.add.sprite(250 + 30*i, 670, 'waterdrop');
      sprite.setName('water');
      this.powerups.add(sprite)
    }

    this.player = this.physics.add.sprite(100, 680, 'mizu');
  }
}

//Animations for Mizu and trees/saplings
createAnimations(){
  this.anims.create({
    key: 'sapling idle',
    frames: this.anims.generateFrameNumbers('sapling', {start: 0, end: 3}),
    frameRate: 3,
    repeat: -1
  });
  this.anims.create({
    key: 'tree idle',
    frames: this.anims.generateFrameNumbers('tree', { start: 0, end: 3}),
    frameRate: 3,
    repeat: -1
  });
  
  this.anims.create({
    key: 'left',
    frames: this.anims.generateFrameNumbers('mizu', { start: 9, end: 12 }),
    frameRate: 8,
    repeat: -1
  });
  this.anims.create({
    key: 'turn',
    frames: [ { key: 'mizu', frame: 0 } ],
    frameRate: 20
  });
  this.anims.create({
    key: 'right',
    frames: this.anims.generateFrameNumbers('mizu', { start: 5, end: 8 }),
    frameRate: 8,
    repeat: -1
  });
  this.anims.create({
    key: 'jumpright',
    frames: this.anims.generateFrameNumbers('mizu', { start: 21, end: 28 }),
    frameRate: 6,
  });
  this.anims.create({
    key: 'jumpleft',
    frames: this.anims.generateFrameNumbers('mizu', { start: 13, end: 20 }),
    frameRate: 6,
  });
  this.anims.create({
    key: 'idle',
    frames: this.anims.generateFrameNumbers('mizu', { frames: [0, 1, 2, 0, 3, 4, 0] }),
    frameRate: 5,
    repeat: -1
  });
  this.anims.create({
    key: 'water',
    frames: this.anims.generateFrameNumbers('mizu', { start: 29, end: 34 }),
    frameRate: 7
  });
  this.anims.create({
    key: 'dying',
    frames: this.anims.generateFrameNumbers('mizu', { start: 39, end: 44 }),
    frameRate: 7
  });
  this.anims.create({
    key: 'damage',
    frames: this.anims.generateFrameNumbers('mizu', { start: 35, end: 38 }),
    frameRate: 4
  });
  this.anims.create({
    key: 'leftLeaf',
    frames: this.anims.generateFrameNumbers('mizu', { start: 58, end: 61 }),
    frameRate: 8,
    repeat: -1
  });
  this.anims.create({
    key: 'turnLeaf',
    frames: [ { key: 'mizu', frame: 49 } ],
    frameRate: 20
  });
  this.anims.create({
    key: 'rightLeaf',
    frames: this.anims.generateFrameNumbers('mizu', { start: 54, end: 57 }),
    frameRate: 8,
    repeat: -1
  });
  this.anims.create({
    key: 'jumprightLeaf',
    frames: this.anims.generateFrameNumbers('mizu', { start: 70, end: 77 }),
    frameRate: 6,
  });
  this.anims.create({
    key: 'jumpleftLeaf',
    frames: this.anims.generateFrameNumbers('mizu', { start: 62, end: 69 }),
    frameRate: 6,
  });
  this.anims.create({
    key: 'idleLeaf',
    frames: this.anims.generateFrameNumbers('mizu', { frames: [49, 50, 51, 49, 52, 53, 49]}),
    frameRate: 5,
    repeat: -1
  });
  this.anims.create({
    key: 'waterLeaf',
    frames: this.anims.generateFrameNumbers('mizu', { start: 78, end: 83 }),
    frameRate: 7
  });


  this.anims.create({
    key: 'enemyLeft',
    frames: this.anims.generateFrameNumbers('enemy', { start: 6, end: 11 }),
    frameRate: 8,
    repeat: -1
  });
  this.anims.create({
    key: 'enemyRight',
    frames: this.anims.generateFrameNumbers('enemy', { start: 0, end: 5 }),
    frameRate: 8,
    repeat: -1
  });
  this.anims.create({
    key: 'enemyAttackLeft',
    frames: this.anims.generateFrameNumbers('enemy', { start: 18, end: 23 }),
    frameRate: 8
  });
  this.anims.create({
    key: 'enemyAttackRight',
    frames: this.anims.generateFrameNumbers('enemy', { start: 12, end: 17 }),
    frameRate: 8
  });
  this.anims.create({
    key: 'enemyDyingLeft',
    frames: this.anims.generateFrameNumbers('enemy', { start: 30, end: 35 }),
    frameRate: 6
  });
  this.anims.create({
    key: 'enemyDyingRight',
    frames: this.anims.generateFrameNumbers('enemy', { start: 24, end: 29 }),
    frameRate: 6
  });

  this.anims.create({
    key: 'background',
    frames: this.anims.generateFrameNumbers('sky', {start: 0, end: 7}),
    frameRate: 10,
    repeat: -1
  });
}

//Setup watchers for specific keys
inputSetup(){
  this.w = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
  this.a = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
  this.s = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
  this.d = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
  this.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
  this.esc = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);
  this.esc.on('down', () => this.pause());
  this.i = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.I);
  this.one = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ONE);
  this.one.on('down', () => this.levelButton(1));
  this.two = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.TWO);
  this.two.on('down', () => this.levelButton(2));
  this.three = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.THREE);
  this.three.on('down', () => this.levelButton(3));
  this.four = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.FOUR);
  this.four.on('down', () => this.levelButton(4));
  this.five = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.FIVE);
  this.five.on('down', () => this.levelButton(5));
  this.six = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SIX);
  this.six.on('down', () => this.levelButton(6));
  this.seven = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SEVEN);
  this.seven.on('down', () => this.levelButton(7));
  this.eight = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.EIGHT);
  this.eight.on('down', () => this.levelButton(8));
  this.nine = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.NINE);
  this.nine.on('down', () => this.levelButton(9));
}


/////////////////////////////////////////////////////// Functions in Update() that handle movement/AI/etc

//Setup for Mizu's death
dead(){
  this.enemies.getChildren().forEach(enemy => {
    enemy.setVelocityX(0);
  });
  this.player.body.setAllowGravity(false);
  this.player.setVelocityX(0);
  this.player.setVelocityY(0);
  this.player.anims.play('dying', true);
  var music = this.sound.add('death');
  music.volume -= 0.7;
  music.play();
  this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2),this.cameras.main.scrollY  + (this.cameras.main.height / 2), 'pause_menu');
  this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2),this.cameras.main.scrollY  + (this.cameras.main.height / 2) - 135,'gameover');
  var image = this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2), this.cameras.main.scrollY  + (this.cameras.main.height / 2) + 30, 'restart');
  image.setInteractive({ useHandCursor: true });
  image.on('pointerdown', () => this.restartButton());
  image = this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2), this.cameras.main.scrollY  + (this.cameras.main.height / 2) + 130, 'mainmenu');
  image.setInteractive({ useHandCursor: true });
  image.on('pointerdown', () => this.menuButton());
}

//Cleanup for beating level
finishedLevel(){
  this.enemies.getChildren().forEach(enemy => {
    enemy.setVelocityX(0);
  });
  this.player.body.setAllowGravity(false);
  this.player.setVelocityX(0);
  this.player.setVelocityY(0);
  this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2),this.cameras.main.scrollY  + (this.cameras.main.height / 2),'next_menu');
  this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2),this.cameras.main.scrollY  + (this.cameras.main.height / 2) - 100,'win');
  if (this.level < 8){
    var image = this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2), this.cameras.main.scrollY  + (this.cameras.main.height / 2) + 20, 'next_level');
    image.setInteractive({ useHandCursor: true });
    image.on('pointerdown', () => this.levelButton(this.level + 1));
  }else if (this.level == 8){
    var image = this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2), this.cameras.main.scrollY  + (this.cameras.main.height / 2) + 20, 'bonus');
    image.setInteractive({ useHandCursor: true });
    image.on('pointerdown', () => this.levelButton(this.level + 1));
  }
  image = this.add.image(this.cameras.main.scrollX + (this.cameras.main.width / 2), this.cameras.main.scrollY  + (this.cameras.main.height / 2) + 110, 'exit');
  image.setInteractive({ useHandCursor: true });
  image.on('pointerdown', () => this.menuButton());
}

//Add water meter to Mizu if in water
inWater(){
  if (this.waterTimer == 0){
    if ((this.waterMeter == 100 && !this.waterUpgraded) || (this.waterMeter == 150 && this.waterUpgraded)){
      if (this.warning != null){this.warning.destroy()}
      this.warning = this.add.text(500,400,"You can't get any more water!", {color: '#000000'}).setScrollFactor(0);
      this.warningTimer = 120;
    }else{
      if (this.waterUpgraded){
        if (this.waterMeter + 20 >= 150){
          this.waterMeter = 150;
          this.waterMask.x = this.waterBar.x;
        }else{
          this.waterMeter += 20;
          this.waterMask.x += (0.133 * this.waterBar.width);
        }
        this.waterText.setText('Water Meter: ' + this.waterMeter + '/150');
      }else{
        if (this.waterMeter + 20 >= 100){
          this.waterMeter = 100;
          this.waterMask.x = this.waterBar.x;
        }else{
          this.waterMeter+=20;
          this.waterMask.x += (0.2 * this.waterBar.width);
        }
        this.waterText.setText('Water Meter: ' + this.waterMeter + '/100');
      }
      var music = this.sound.add('water');
      music.volume -= 0.7;
      music.play();
      this.waterTimer = 60;
    }
  }else{
    this.waterTimer--;
  }
}

//If Mizu is in the sun, damage him
inSun(){
  if (this.shadeTimer == 0){
    this.takeDamage();
  }else{
    this.shadeTimer--;
  }
}

//Handles all movement for Mizu
movement(){
  //moving left
  if (this.a.isDown){
    this.player.setVelocityX(-300);
    if (!this.invincible){
      if (this.player.anims.getCurrentKey() != 'jumpleft'){
        if (this.player.anims.getCurrentKey() != 'jumpright' && this.player.anims.getCurrentKey() != 'water' && this.player.anims.getCurrentKey() != 'damage'){
          this.player.anims.play('left', true);
        }
      }
    }else{
      if (this.player.anims.getCurrentKey() != 'jumpleftLeaf'){
        if (this.player.anims.getCurrentKey() != 'jumprightLeaf' && this.player.anims.getCurrentKey() != 'waterLeaf' && this.player.anims.getCurrentKey() != 'damageLeaf'){
          this.player.anims.play('leftLeaf', true);
        }
      }
    }
  }

  //moving right
  else if (this.d.isDown){
    this.player.setVelocityX(300);
    if (!this.invincible){
      if (this.player.anims.getCurrentKey() != 'jumpleft'){
        if (this.player.anims.getCurrentKey() != 'jumpright' && this.player.anims.getCurrentKey() != 'water' && this.player.anims.getCurrentKey() != 'damage'){
          this.player.anims.play('right', true);
        }
      }
    }else{
      if (this.player.anims.getCurrentKey() != 'jumpleftLeaf'){
        if (this.player.anims.getCurrentKey() != 'jumprightLeaf' && this.player.anims.getCurrentKey() != 'waterLeaf' && this.player.anims.getCurrentKey() != 'damageLeaf'){
          this.player.anims.play('rightLeaf', true);
        }
      }
    }
  }

  //Not moving in x direction/idle
  else{
    this.player.setVelocityX(0);
    if (!this.invincible){
      if (this.player.anims.getCurrentKey() == 'left' || this.player.anims.getCurrentKey() == 'right'){
        this.player.anims.play('turn', true);
      }
      else{
        if (this.player.anims.getCurrentKey() == 'jumpright' || this.player.anims.getCurrentKey() == 'jumpleft' || 
        this.player.anims.getCurrentKey() == 'water' || this.player.anims.getCurrentKey() == 'damage' || this.player.anims.getCurrentKey() == 'damage'){}
        else{
          this.player.anims.play('idle', true);
        }
      }
    }else{
      if (this.player.anims.getCurrentKey() == 'leftLeaf' || this.player.anims.getCurrentKey() == 'rightLeaf'){
        this.player.anims.play('turnLeaf', true);
      }
      else{
        if (this.player.anims.getCurrentKey() == 'jumprightLeaf' || this.player.anims.getCurrentKey() == 'jumpleftLeaf' || 
        this.player.anims.getCurrentKey() == 'waterLeaf' || this.player.anims.getCurrentKey() == 'damageLeaf' || this.player.anims.getCurrentKey() == 'damageLeaf'){}
        else{
          this.player.anims.play('idleLeaf', true);
        }
      }
    }
  }

  //Jumping
  if (this.w.isDown && (this.player.body.onFloor() || this.jumpable)){
    if (this.player.anims.getCurrentKey() == 'jumpright' || this.player.anims.getCurrentKey() == 'jumpleft' 
    || this.player.anims.getCurrentKey() == 'jumprightLeaf' || this.player.anims.getCurrentKey() == 'jumpleftLeaf'){}
    else{
      var music = this.sound.add('jump');
      music.volume -= 0.7;
      music.play();
      //Left vs right jump, default right
      if (this.a.isDown){
        this.player.setVelocityY(-500);
        if (!this.invincible){
          if (this.player.anims.getCurrentKey() != 'water' && this.player.anims.getCurrentKey() != 'damage'){
            this.player.anims.play('jumpleft', true);
          }
          this.player.anims.nextAnim = 'left';
        }else{
          if (this.player.anims.getCurrentKey() != 'waterLeaf' && this.player.anims.getCurrentKey() != 'damageLeaf'){
            this.player.anims.play('jumpleftLeaf', true);
          }
          this.player.anims.nextAnim = 'leftLeaf';
        }
      }else{
        this.player.setVelocityY(-500);
        if (!this.invincible){
          if (this.player.anims.getCurrentKey() != 'water' && this.player.anims.getCurrentKey() != 'damage'){
            this.player.anims.play('jumpright', true);
          }
          this.player.anims.nextAnim = 'right';
        }else{
          if (this.player.anims.getCurrentKey() != 'waterLeaf' && this.player.anims.getCurrentKey() != 'damageLeaf'){
            this.player.anims.play('jumprightLeaf', true);
          }
          this.player.anims.nextAnim = 'rightLeaf';
        }
      }
    }
  }
}

//Handles all necessary checks for watering
watering(){
  if (Phaser.Input.Keyboard.JustDown(this.space) && (this.player.body.onFloor() || this.jumpable)){
    //If not already watering

    if (this.player.anims.getCurrentKey() != 'water'){
      if (this.player.anims.getCurrentKey() != 'waterLeaf'){
        //If watering will kill you, add warning for player
        if (this.waterMeter == 1 && !this.invincible){
          if (this.warningTimer == -1){
            this.warning = this.add.text(520,400,"You can't water plants with 1 hp!.", {color: '#000000'}).setScrollFactor(0);
            this.warningTimer = 120;}
        }else{
          if (!this.invincible){
            this.player.anims.play('water', true);
            this.player.anims.nextAnim = 'idle';
          }else{
            this.player.anims.play('waterLeaf', true);
            this.player.anims.nextAnim = 'idleLeaf';
          }

          //checks to see if sapling in range
          this.saps.getChildren().forEach( sapdist => {
            if (Phaser.Math.Distance.BetweenPoints(this.player, sapdist) < 135){
              sapdist.setVisible(false);
              sapdist.destroy();
              this.trees.getChildren().forEach( treedist =>{
                if (Phaser.Math.Distance.BetweenPoints(this.player, treedist) < 135){
                  treedist.setVisible(true);
                  this.treesWatered += 1;
                  this.treeText.setText('Saplings Watered: ' + this.treesWatered + '/' + this.maxSaplings);
                  //Play sound effect
                  var music = this.sound.add('grow');
                  music.volume -= 0.7;
                  music.play();
                }});}
          });

          //Check if any enemies nearby to kill
          this.enemies.getChildren().forEach( enemy => {
            if (Phaser.Math.Distance.Between(this.player.x, this.player.y, enemy.x, enemy.y) < 64){
              if (enemy.anims.getCurrentKey() == 'enemyLeft' || enemy.anims.getCurrentKey() == 'enemyAttackLeft'){
                //enemy.anims.nextAnim = 'enemyDyingLeft';
                enemy.anims.play('enemyDyingLeft', true);
              }else if (enemy.anims.getCurrentKey() == 'enemyRight' || enemy.anims.getCurrentKey() == 'enemyAttackRight'){
                //enemy.anims.nextAnim = 'enemyDyingRight';
                enemy.anims.play('enemyDyingRight', true);
              }

              this.time.addEvent({
                delay: 10000,
                callback: ()=>{
                  this.enemies.remove(enemy, true, true);
                }
              })
            }
          });

          //Deplete water, set to 1 if you would die otherwise
          if (this.waterMeter - 10 <= 0){
            this.waterMeter = 1;
          }else{
            this.waterMeter -= 10;
          }

          //Update text/bars
          if (this.waterUpgraded){
            this.waterMask.x -= (0.067 * this.waterBar.width);
            this.waterText.setText('Water Meter: ' + this.waterMeter + '/150');
          }else{
            this.waterMask.x -= (0.1 * this.waterBar.width);
            this.waterText.setText('Water Meter: ' + this.waterMeter + '/100');
          }
          //Play sound effect
          var music = this.sound.add('water');
          music.volume -= 0.7;
          music.play();
        }}}}
  }

  //Enemy ai for walking back and forth/attacking
  enemyAI(){
    this.enemies.getChildren().forEach(enemy => {
      enemy.setVelocityX(0);
    });

    if (this.enemyTimer == 0){
      //If they were moving, let enemy rest
      if (this.enemyIdling == false){
        this.enemyIdling = true;
        this.enemyTimer = 120;
      }else{
        this.enemies.getChildren().forEach(enemy => {
        //Else, start them moving left and right
          if (enemy.anims.getCurrentKey() == 'enemyLeft'){
            enemy.anims.play('enemyRight');
            this.enemyTimer = 60;
            this.enemyIdling = false;
          }else if (enemy.anims.getCurrentKey() == 'enemyRight'){
            enemy.anims.play('enemyLeft');
            this.enemyTimer = 60;
            this.enemyIdling = false;
          }
        });
      }
    }else{
      this.enemyTimer--;
      //Timer going down and move enemies if not idling
      this.enemies.getChildren().forEach(enemy => {
        if (this.enemyIdling == false && (enemy.anims.getCurrentKey() == 'enemyLeft' || enemy.anims.getCurrentKey() == 'enemyAttackLeft')){
          enemy.setVelocityX(-150);
        }else if (this.enemyIdling == false && (enemy.anims.getCurrentKey() == 'enemyRight' || enemy.anims.getCurrentKey() == 'enemyAttackRight')){
          enemy.setVelocityX(150);
        }
      });
    }

    this.enemies.getChildren().forEach(enemy => {
      var dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, enemy.x, enemy.y);
      if (dist < 64){
        if (enemy.anims.getCurrentKey() == 'enemyLeft'){
          enemy.anims.play('enemyAttackLeft');
          enemy.anims.nextAnim = 'enemyLeft';
          this.takeDamage();
        }else if (enemy.anims.getCurrentKey() == 'enemyRight'){
          enemy.anims.play('enemyAttackRight');
          enemy.anims.nextAnim = 'enemyRight';
          this.takeDamage();
        }
      }
    });
  }

  //Damage helper function
  takeDamage(){
    if (!this.invincible){
      if (this.waterMeter - 10 < 0){
        this.waterMeter = 0;
      }else{
        this.waterMeter -= 10;
      }
      if (this.waterUpgraded){
        this.waterMask.x -= (0.067 * this.waterBar.width);
        this.waterText.setText('Water Meter: ' + this.waterMeter + '/150');
      }else{
        this.waterMask.x -= (0.1 * this.waterBar.width);
        this.waterText.setText('Water Meter: ' + this.waterMeter + '/100');
      }
      this.player.setTint(0xcc338b);
      this.player.anims.play('damage', true);
      this.player.anims.nextAnim = 'idle';
      var music = this.sound.add('hurt');
      music.volume -= 0.7;
      music.play();
      this.shadeTimer = 120;
      this.time.addEvent({
        delay: 1000,
        callback: ()=>{
          this.player.clearTint();
        }
      })
    }
  }

  //Power up Mizu depending on type of powerup picked up
  powerUp(){
    this.powerups.getChildren().forEach(powerup => {
      var dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, powerup.x, powerup.y);
      if (dist < 64){
        if (this.warning != null){this.warning.destroy()}
        if (powerup.name == 'leaf'){
          this.warning = this.add.text(480,400,"Got leaf hat! Invincible for 10 seconds.", {color: '#000000'}).setScrollFactor(0);
          this.warningTimer = 120;
          var music = this.sound.add('water');
          music.volume -= 0.7;
          music.play();
          this.invincible = true;
          this.time.addEvent({
            delay: 10000,
            callback: ()=>{
              this.invincible = false;
            }
          })
        }else if (powerup.name == 'water'){
          this.warning = this.add.text(480,400,"Increased water meter!", {color: '#000000'}).setScrollFactor(0);
          this.warningTimer = 120;
          var music = this.sound.add('water');
          music.volume -= 0.7;
          music.play();
          if (this.waterMeter + 50 >= 150){
            this.waterMeter = 150;
            this.waterMask.x = this.waterBar.x;
          }else{
            this.waterMeter += 50;
            this.waterMask.x = this.waterBar.x;
            this.waterMask.x -= (((150 - this.waterMeter) / 150) * this.waterBar.width);
          }

          this.waterText.setText('Water Meter: ' + this.waterMeter + '/150');
          this.waterUpgraded = true;
        }

        this.powerups.remove(powerup, true, true);
      }
    });
  }

};