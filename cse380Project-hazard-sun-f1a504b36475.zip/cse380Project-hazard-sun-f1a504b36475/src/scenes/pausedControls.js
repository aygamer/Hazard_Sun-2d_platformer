export default class pausedControls extends Phaser.Scene {
    constructor () {
      super('PausedControls');
    }

    init(){
        this.imageGroup;
    }

    preload(){}

    create(){
        console.log("yo");
        this.imageGroup = this.add.group();
        var image = this.add.image(600,400, 'background_blurred');
        this.imageGroup.add(image);
        var logo = this.add.image(370,120, 'logo');
        logo.setScale(0.5)
        this.imageGroup.add(logo);
        image = this.add.image(640, 120, "controls title");
        this.imageGroup.add(image);
        var back = this.add.image(90,40, 'back_button').setInteractive({ useHandCursor: true });
        back.on('pointerdown', () => this.backMenu());
        this.imageGroup.add(back);

        image = this.add.image(220, 320, 'wasd');
        this.imageGroup.add(image);
        image = this.add.image(220,500,"wasd text");
        this.imageGroup.add(image);

        image = this.add.image(620, 360, 'space');
        this.imageGroup.add(image);
        image = this.add.image(620,480,"space text");
        this.imageGroup.add(image);

        image = this.add.image(990, 360, 'esc');
        this.imageGroup.add(image);
        image = this.add.image(990,480,"esc text");
        this.imageGroup.add(image);
    }

    backMenu(){
        var sound = this.sound.add('click');
        sound.volume-= 0.4;
        sound.play();
        this.imageGroup.destroy(true);
        this.scene.resume('Paused');
        this.scene.stop();
    }
}