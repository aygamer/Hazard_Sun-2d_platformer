export default class controlsScene extends Phaser.Scene {
  constructor () {
    super('Controls');
  }
 
  preload () {
  }
 
  create () {
    this.add.image(600,400, 'background_blurred');
    var logo = this.add.image(370,120, 'logo');
    logo.setScale(0.5)
    this.add.image(640, 120, "controls title");
    var back = this.add.image(90,40, 'back_button').setInteractive({ useHandCursor: true });
    back.on('pointerdown', () => this.backButton());

    this.add.image(220, 320, 'wasd');
    this.add.image(220,500,"wasd text");

    this.add.image(620, 360, 'space');
    this.add.image(620,480,"space text");

    this.add.image(990, 360, 'esc');
    this.add.image(990,480,"esc text");

  }

  backButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Title');
  }
};