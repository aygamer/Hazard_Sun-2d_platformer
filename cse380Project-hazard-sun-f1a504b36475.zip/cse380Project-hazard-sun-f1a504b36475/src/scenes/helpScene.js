export default class helpScene extends Phaser.Scene {
  constructor () {
    super('Help');
  }
 
  preload () {
  }
 
  create () {
    this.add.image(600,400, 'background_blurred');
    var logo = this.add.image(370,120, 'logo');
    logo.setScale(0.5)
    this.add.image(610, 130, "help title");
    var back = this.add.image(90,40, 'back_button').setInteractive({ useHandCursor: true });
    back.on('pointerdown', () => this.backButton());

    this.add.image(200,300, "backstory");
    this.add.image(200,460, "backstory text");

    this.add.image(590,290, "characters");
    this.add.image(590,550, "characters text");

    this.add.image(975,300,"devs");
    this.add.image(975,480, "devs text");

  }

  backButton() {
    var sound = this.sound.add('click');
    sound.volume-= 0.4;
    sound.play();
    this.scene.start('Title');
  }
};